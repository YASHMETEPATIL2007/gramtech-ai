# Manual Test Checklist

- [ ] Open `index.html` on desktop.
- [ ] Open the page on a mobile-sized viewport.
- [ ] Try each learning suggestion.
- [ ] Test an empty question and an unsupported question.
- [ ] Generate a roadmap for every career option.
- [ ] Check keyboard navigation and visible focus.
- [ ] Check browser console for errors.
- [ ] Confirm the page does not claim live AI integration.
- [ ] Confirm sample projects are labelled illustrative.
- [ ] If deployed, open the public URL in a private/incognito window.
