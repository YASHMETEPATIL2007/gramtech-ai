# GramTech AI — Technical Design

## Current architecture
```text
Student / Teacher / Reviewer
          |
          v
Responsive browser UI (index.html + styles.css)
          |
          v
Client-side interactions (script.js)
   |            |             |
   v            v             v
Sample Q&A   Career plans   Illustrative
responses                  project cards
```
The current prototype is static. It has no server, database, user account, external AI API or personal-data collection. It can be hosted as a static website.

## Components
- Presentation: semantic HTML and responsive CSS.
- Interaction: plain JavaScript for topic examples, roadmap selection and mobile navigation.
- Hosting option: GitHub Pages or another static host.

## Future architecture (proposal only)
```text
Student / Teacher
       |
       v
Accessible web app / offline lesson cache
       |
       v
Secure application API
   |                 |
   v                 v
Reviewed learning   School-managed content
content + AI        with access controls
service
```
Future services are proposals and are not implemented. Before an AI service or school data is introduced, the project needs school approval, privacy/security review, age-appropriate safeguards, reviewed content, cost planning and human oversight.

## Design principles
- Mobile-responsive and lightweight.
- Do not collect student personal data in this prototype.
- Clearly label sample content and simulated AI functionality.
- Keep controls keyboard-operable and labelled.
- Validate learning content with educators.
- Consider local-language support and low-connectivity conditions.

## Suggested evaluation
For an approved pilot, measure task completion, student/teacher feedback, repeat use, access on low-end devices and educator-designed pre/post learning checks. Do not claim impact before it is measured.
