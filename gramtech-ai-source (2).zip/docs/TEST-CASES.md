# Test Cases

| ID | Test | Steps | Expected result |
|---|---|---|---|
| TC-01 | Page loads | Open `index.html` | Main page and sections render |
| TC-02 | Water cycle | Click Water cycle | Explanation and practice questions appear |
| TC-03 | Plants | Click Plants | Plant explanation appears |
| TC-04 | Unknown topic | Enter unsupported topic | Demo explains no prepared response exists |
| TC-05 | Empty question | Click Ask with empty input | Prompt asks for a question |
| TC-06 | Career roadmap | Select Software developer and build roadmap | Relevant skill and project suggestions appear |
| TC-07 | Mobile navigation | Use narrow viewport and open menu | Navigation toggles open and closed |
| TC-08 | Keyboard use | Tab through controls | Links, input and buttons are reachable |
| TC-09 | Offline local files | Open files locally | Core interactions work without external libraries |
| TC-10 | Transparency | Inspect assistant and sample cards | Demo and illustrative content are clearly labelled |

Record actual pass/fail results after testing; do not mark tests as passed before running them.
